﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Admin_frmEmpSalary : System.Web.UI.Page
{
    clsDepartment objDept = new clsDepartment();
    clsUser objUser = new clsUser();
    protected void Page_Load(object sender, EventArgs e)
    {
        lblMsg.Text = "";
        if (!IsPostBack)
        {
            BindEmployees();
        }
    }
    void BindEmployees()
    {
        try
        {
            DataSet ds = objDept.GetEmployeesForSalary();
            if (ds.Tables[0].Rows.Count > 0)
            {
                ddlEmp.DataSource = ds.Tables[0];
                ddlEmp.DataValueField = "UserId";
                ddlEmp.DataTextField = "UserName";
                ddlEmp.DataBind();
                ddlEmp.Items.Insert(0, "--Select Emp--");
            }
            else
            {
                lblMsg.Text = "No Records Found..";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    void ClearData()
    {
        txtDA.Text = "";
        txtHRA.Text = "";
        txtSal.Text="";
        txtDesg.Text = "";
        txtDept.Text = "";
        ddlEmp.SelectedIndex = 0;
    }
    protected void ddlEmp_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            lblMsg.Text = "";
            //Gvloan.Visible = false;
            objDept.EmpId = Convert.ToInt32(ddlEmp.SelectedValue);
            DataSet ds = objDept.GetDeptDesgByEmp();
            //DataRow drDed = ds.Tables[1].Rows[0];
            DataRow dr = ds.Tables[0].Rows[0];
            if (ds.Tables[0].Rows.Count > 0)
            {
                txtDept.Text = dr["DeptName"].ToString();
                txtDesg.Text = dr["DesgName"].ToString();
            }
            else
            {
                lblMsg.Text = "No Records Found..";
            }
            if (ds.Tables[3].Rows.Count > 0)
            {
                DataRow dr1 = ds.Tables[3].Rows[0];
                txtDA.Text = Convert.ToString(dr1["DA"]);
                txtHRA.Text = Convert.ToString(dr1["HRA"]);
                txtSal.Text = Convert.ToString(dr1["BasicSalary"]);
                
            }

            //if (ds.Tables[1].Rows.Count > 0)
            //{
            //    Gvloan.DataSource = ds.Tables[1];
            //    Gvloan.DataBind();
            //    Gvloan.Visible = true;
                
            //}
            //else
            //{
            //    lblMsg.Text = "No Loans Taken By this Employee..";
            //    txtDed.Text = 0.ToString();
            //}
            // DataRow drDed = ds.Tables[2].Rows[0];
            //if (ds.Tables[2].Rows.Count > 0)
            //{
            //    txtDed.Text = drDed["Deduction"].ToString();
            //    if (txtDed.Text == "")
            //    {
            //        txtDed.Text = 0.ToString();
            //    }
            //}
            //else
            //{
            //    lblMsg.Text = "No Loans Taken By this Employee..";
            //    txtDed.Text = 0.ToString();
            //}
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            lblMsg.Text = "";
            objUser.EmpId = Convert.ToInt32(ddlEmp.SelectedValue);
            objUser.DeptName = txtDept.Text;
            objUser.DesgName = txtDesg.Text;
            objUser.Basic = Convert.ToDecimal(txtSal.Text);
            objUser.HRA = Convert.ToDecimal(txtHRA.Text);
            objUser.DA = Convert.ToDecimal(txtDA.Text);
            lblMsg.Text = objUser.InsertSalaryDetails();
            ClearData();
            BindEmployees();
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        ClearData();
        lblMsg.Text = "";
    }
}
