﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Admin_frmAddDepartments : System.Web.UI.Page
{
    clsDepartment objDept = new clsDepartment();
    //ClsBranch objBranch = new ClsBranch();
    protected void Page_Load(object sender, EventArgs e)
    {
        lblMsg.Text = "";
        if (!IsPostBack)
        {
            //BindBranches();
        }
    }
    //void BindBranches()
    //{
    //    try
    //    {
    //        DataSet ds = objBranch.GetAssignedBranches();
    //        if (ds.Tables[0].Rows.Count > 0)
    //        {
    //            ddlBranch.DataSource = ds.Tables[0];
    //            ddlBranch.DataValueField = "BranchId";
    //            ddlBranch.DataTextField = "BranchName";
    //            ddlBranch.DataBind();
    //            ddlBranch.Items.Insert(0,"--Select Branch--");
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        lblMsg.Text = ex.Message;
    //    }
    //}
    void ClearData()
    {
        txtDesc.Text = "";
        //ddlBranch.SelectedIndex = 0;
        txtName.Text = "";
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            //objDept.BranchId = Convert.ToInt32(ddlBranch.SelectedValue);
            objDept.DeptName = txtName.Text;
            //objDept.Location = txtLocation.Text;
            objDept.Desc = txtDesc.Text;

            lblMsg.Text = objDept.AddDept();
            ClearData();
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        ClearData();
        lblMsg.Text = "";
    }
}
