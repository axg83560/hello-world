﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Admin_frmLoanRequests : System.Web.UI.Page
{
    clsLoanTypes objLoan = new clsLoanTypes();
    protected void Page_Load(object sender, EventArgs e)
    {
        lblMsg.Text = "";
        if (!IsPostBack)
        {
            GetLoanRequests();
        }
    }
    void GetLoanRequests()
    {
        try
        {
            DataSet ds = objLoan.GetLoanRequests();
            ViewState["Data"] = ds;
            if (ds.Tables[0].Rows.Count > 0)
            {
                GvLoan.DataSource = ds.Tables[0];
                GvLoan.DataBind();
            }
            else
            {
                lblMsg.Text = "No Records Available..";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void GvLoan_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            DataSet ds = (DataSet)ViewState["Data"];
            if (ds.Tables[0].Rows.Count > 0)
            {
                GvLoan.PageIndex = e.NewPageIndex;
                GvLoan.DataSource = ds.Tables[0];
                GvLoan.DataBind();
            }
            else
            {
                lblMsg.Text = "No Records Available..";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void GvLoan_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            lblMsg.Text = "";
            objLoan.SNo = Convert.ToInt32(e.CommandArgument);
            int i = objLoan.ChangeRequestStatus();
            if (i > 0)
            {
                lblMsg.Text = "Request forward to Advisor Successfully..";
                GetLoanRequests();
            }

            else
            {
                lblMsg.Text = "Error.. Try again..";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
}
