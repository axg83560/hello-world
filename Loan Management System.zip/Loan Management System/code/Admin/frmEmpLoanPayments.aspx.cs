﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Admin_frmEmpLoanPayments : System.Web.UI.Page
{
    clsLoanTypes objLoan = new clsLoanTypes();
    protected void Page_Load(object sender, EventArgs e)
    {
        lblMsg.Text = "";
        if (!IsPostBack)
        {
            txtBal.Text = "";
            txtDed.Text = "";
            BindLoanTakenEmployees();
        }
    }
    void BindLoanTakenEmployees()
    {
        try
        {
            DataSet ds = objLoan.GetLoanTakenEmployees();
            ddlEmp.DataSource = ds.Tables[0];
            ddlEmp.DataTextField = "UserName";
            ddlEmp.DataValueField = "UserId";
            ddlEmp.DataBind();
            ddlEmp.Items.Insert(0, "--Select Employee--");
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            objLoan.EmpId = Convert.ToInt32(ddlEmp.SelectedValue);
            objLoan.LoanTypeId = Convert.ToInt32(ddlLoan.SelectedValue);
            objLoan.Balance = Convert.ToDecimal(txtBal.Text);
            objLoan.Deduction = Convert.ToDecimal(txtDed.Text);
            lblMsg.Text = objLoan.InsertEmpLoanPayments();
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        txtBal.Text = "";
        ddlLoan.SelectedIndex = 0;
        ddlLoan.Enabled = false;
        ddlEmp.SelectedIndex = 0;
        txtDed.Text = "";
    }
    protected void ddlEmp_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlEmp.SelectedIndex != 0)
            {
                objLoan.EmpId = Convert.ToInt32(ddlEmp.SelectedValue);
                DataSet ds = objLoan.GetLoanDetailsByEmp();
                if (ds.Tables[0].Rows.Count > 0)
                {
                    ddlLoan.DataSource = ds;
                    ddlLoan.DataValueField = "LoanTypeId";
                    ddlLoan.DataTextField = "LoanTypeName";
                    ddlLoan.DataBind();
                    ddlLoan.Enabled = true;
                    ddlLoan.Items.Insert(0, "--Select Loan--");
                }
            }
            else
            {
                lblMsg.Text = "Select Employee";
                ddlLoan.Enabled = false;
                ddlLoan.Items.Insert(0, "--Select Loan--");
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void ddlLoan_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlLoan.SelectedIndex != 0)
            {
                //objLoan.EmpId = Convert.ToInt32(ddlEmp.SelectedValue);
                //objLoan.LoanTypeId = Convert.ToInt32(ddlLoan.SelectedValue);
                clsLoanTypes.GetBalanceByEmp(Convert.ToInt32(ddlEmp.SelectedValue), Convert.ToInt32(ddlLoan.SelectedValue));
                if (clsLoanTypes.DeductionAmt != 0 && clsLoanTypes.BalAmt != 0)
                {
                    txtBal.Text = clsLoanTypes.BalAmt.ToString();
                    txtDed.Text = clsLoanTypes.DeductionAmt.ToString();
                }
                else
                {
                    lblMsg.Text = clsLoanTypes.Message.ToString();
                }
            }
            else
            {
                txtBal.Text = "";
                
                txtDed.Text = "";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
}
