﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Admin_frmUpdateLoanAvailability : System.Web.UI.Page
{
    clsLoanTypes objLoan = new clsLoanTypes();
    protected void Page_Load(object sender, EventArgs e)
    {
        lblMsg.Text = "";
        if (!IsPostBack)
        {
            BindLoanIds();
        }
    }
    void BindLoanIds()
    {
        try
        {
            DataSet ds = objLoan.GetLoanIds();
            if (ds.Tables[0].Rows.Count > 0)
            {
                ddlLoan.DataSource = ds.Tables[0];
                ddlLoan.DataValueField = "SNo";
                ddlLoan.DataBind();
                ddlLoan.Items.Insert(0, "--Select LoanId--");
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;  
        }
    }
    void ClearData()
    {
        ddlLoan.SelectedIndex = 0;
        txtAmount.Text = "";
        txtDesg.Text = "";
        txtDuration.Text = "";
        txtLoan.Text = "";
    }
    protected void ddlLoan_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            lblMsg.Text = "";
            if (ddlLoan.SelectedIndex != 0)
            {
                objLoan.SNo = Convert.ToInt32(ddlLoan.SelectedValue);
                DataSet ds = objLoan.GetLoanAvailabilityDetailsById();
                DataRow dr = ds.Tables[0].Rows[0];
                if (ds.Tables[0].Rows.Count > 0)
                {
                    txtLoan.Text = dr["LoanTypeName"].ToString();
                    txtDuration.Text = dr["Duration"].ToString();
                    txtAmount.Text = dr["Amount"].ToString();
                    txtDesg.Text = dr["DesgName"].ToString();
                }
            }
            else
            {
                ClearData();
                lblMsg.Text = "Select LoanId..";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            objLoan.SNo = Convert.ToInt32(ddlLoan.SelectedValue);
            //objLoan.DesgName = txtDesg.Text;
            //objLoan.TypeName = txtLoan.Text;
            objLoan.Amount = Convert.ToDecimal(txtAmount.Text);
            objLoan.Duration = txtDuration.Text;
            
            lblMsg.Text = objLoan.UpdateLoanAvailability();
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        ClearData();
        lblMsg.Text = "";
    }
}
