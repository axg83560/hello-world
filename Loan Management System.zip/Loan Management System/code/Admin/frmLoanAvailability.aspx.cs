﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Admin_frmLoanAvailability : System.Web.UI.Page
{
    clsDepartment objDept = new clsDepartment();
    clsLoanTypes objLoan = new clsLoanTypes();
    protected void Page_Load(object sender, EventArgs e)
    {
        lblMsg.Text = "";
        if (!IsPostBack)
        {
            BindLoanTypes();
            BindDesg();
        }
    }
    public void BindLoanTypes()
    {
        try
        {
            DataSet ds = objLoan.GetLoanTypes();
            ddlType.DataSource = ds.Tables[0];
            ddlType.DataTextField = "LoanTypeName";
            ddlType.DataValueField = "LoanTypeId";
            ddlType.DataBind();
            ddlType.Items.Insert(0, "--Select LoanType--");
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    public void BindDesg()
    {
        try
        {
            DataSet dsDesg = objDept.GetDesignations();
            ddlDesg.DataSource = dsDesg.Tables[0];
            ddlDesg.DataTextField = "DesgName";
            ddlDesg.DataValueField = "DesignationId";
            ddlDesg.DataBind();
            ddlDesg.Items.Insert(0, "--Select Designation--");
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    void ClearData()
    {
        txtDuration.Text = "";
        txtAmount.Text = "";
        ddlDesg.SelectedIndex = 0;
        ddlType.SelectedIndex = 0;
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            lblMsg.Text = "";
            objLoan.LoanTypeId = Convert.ToInt32(ddlType.SelectedValue);
            objLoan.DesgId = Convert.ToInt32(ddlDesg.SelectedValue);
            objLoan.Amount = Convert.ToDecimal(txtAmount.Text);
            objLoan.Duration = txtDuration.Text;
            lblMsg.Text = objLoan.InsertLoanAvailability();
            ClearData();
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        ClearData();
        lblMsg.Text = "";
    }
}
