﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Admin_frmViewEmpSalary : System.Web.UI.Page
{
    clsUser objUser = new clsUser();
    clsLoanTypes objLoan = new clsLoanTypes();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            lblLoan.Visible = false;
            BindEmployees();
        }
    }
    void BindEmployees()
    {
        try
        {
            DataSet ds = objUser.BindEmployees();
            if (ds.Tables[0].Rows.Count > 0)
            {
                ddlEmp.DataSource = ds.Tables[0];
                ddlEmp.DataValueField = "UserId";
                ddlEmp.DataTextField = "UserName";
                ddlEmp.DataBind();
                ddlEmp.Items.Insert(0, "--Select Emp--");
            }
            else
            {
                lblMsg.Text = "No Records Found..";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void btnShow_Click(object sender, EventArgs e)
    {
        try
        {
            GvAvailability.Visible = false;
            lblLoan.Visible = false;
            lblMsg.Text = "";
            if (ddlEmp.SelectedIndex != 0)
            {
                objUser.EmpId = Convert.ToInt32(ddlEmp.SelectedValue);
                DataSet ds = objUser.GetSalaryDetailsByEmp();
                if (ds.Tables[0].Rows.Count > 0)
                {
                    GvSal.DataSource = ds.Tables[0];
                    GvSal.DataBind();
                    GvSal.Visible = true;
                }
            }
            else
            {
                lblMsg.Text = "Select Employee..";
                GvSal.Visible = false;
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void GvSal_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if(e.CommandName=="Details")
            {
                objLoan.EmpId = Convert.ToInt32(e.CommandArgument);
                ViewState["Emp"] = Convert.ToInt32(e.CommandArgument);

                DataSet ds = objLoan.GetLoanDetailsByEmp();
                if (ds.Tables[0].Rows.Count > 0)
                {
                    GvAvailability.DataSource = ds.Tables[0];
                    GvAvailability.DataBind();
                    GvAvailability.Visible = true;
                    lblLoan.Visible = true;
                }
                else
                {
                    lblMsg.Text = "No Loans Found taken by this Employee..";
                    GvAvailability.Visible = false;
                    lblLoan.Visible = false;
                }
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
}
