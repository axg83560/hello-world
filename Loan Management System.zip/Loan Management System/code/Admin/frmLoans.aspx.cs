﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Admin_frmLoans : System.Web.UI.Page
{
    clsLoanTypes objLoan = new clsLoanTypes();
    protected void Page_Load(object sender, EventArgs e)
    {
        lblMsg.Text = "";

        if (!IsPostBack)
        {
            BindAdvisors();
        }
    }
    void ClearData()
    {
        txtDesc.Text = "";
        //ddlBranch.SelectedIndex = 0;
        txtName.Text = "";
    }
    void BindAdvisors()
    {
        try
        {
            DataSet ds = objLoan.GetAdvisors();
            if (ds.Tables[0].Rows.Count > 0)
            {
                ddlAdvisor.DataSource = ds.Tables[0];
                ddlAdvisor.DataValueField = "UserId";
                ddlAdvisor.DataTextField = "UserName";
                ddlAdvisor.DataBind();
                ddlAdvisor.Items.Insert(0, "--Select Advisor--");
            }
            else
            {
                lblMsg.Text = "No Advisors Available..";
                ddlAdvisor.Items.Insert(0, "--Select Advisor--");
            }
        }
        catch (Exception ex)
        {

            lblMsg.Text = ex.Message;
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            objLoan.TypeName = txtName.Text;
            objLoan.Desc = txtDesc.Text;
          
            objLoan.AdvisorId = Convert.ToInt32(ddlAdvisor.SelectedValue); 
            lblMsg.Text = objLoan.InsertLoanTypes();
            ClearData();
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        ClearData();
        lblMsg.Text = "";
    }
    protected void ddlAdvisor_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
