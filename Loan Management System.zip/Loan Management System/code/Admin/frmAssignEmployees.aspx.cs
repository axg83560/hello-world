﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Admin_frmAssignEmployees : System.Web.UI.Page
{
    clsDepartment objDept = new clsDepartment();
    clsUser objUser = new clsUser();
    protected void Page_Load(object sender, EventArgs e)
    {
        lblMsg.Text = "";
        if (!IsPostBack)
        {
            tblnew.Visible = false;
            BindDept();               
            BindDesg();
        }
    }

    void BindDept()
    {
        try
        {
            //objDept.HR = Convert.ToInt32(Session["HRId"]);
            DataSet ds = objDept.GetDepartments();
            if (ds.Tables[0].Rows.Count > 0)
            {
                ddlDept.DataSource = ds.Tables[0];
                ddlDept.DataValueField = "DepartmentId";
                ddlDept.DataTextField = "DeptName";
                ddlDept.DataBind();
                ddlDept.Items.Insert(0, "--Select Dept--");
            }
            else
            {
                lblMsg.Text = "No Depts Available..";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }

    public void BindDesg()
    {
        try
        {
            DataSet dsDesg = objDept.GetDesignations();
            ddlDesg.DataSource = dsDesg.Tables[0];
            ddlDesg.DataTextField = "DesgName";
            ddlDesg.DataValueField = "DesignationId";
            ddlDesg.DataBind();
            ddlDesg.Items.Insert(0, "--Select Designation--");
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            lblMsg.Text = "";
            foreach (GridViewRow dRow in GridView1.Rows)
            {
                CheckBox chk = (CheckBox)dRow.FindControl("CheckBox1");
                if (chk.Checked == true)
                {
                    Label lblId = (Label)dRow.FindControl("lblEmpId");
                    objDept.EmpId = Convert.ToInt32( lblId.Text);
                    objDept.DeptId = Convert.ToInt32(ddlDept.SelectedItem.Value);
                    //objDept.HR = Convert.ToInt32(Session["HRId"]);
                    objDept.DesgId = Convert.ToInt32(ddlDesg.SelectedValue);
                    lblMsg.Text = objDept.AssignEmpToDept();
                    btnShow_Click(sender, e);

                    //int result = clsEmployee.AllocatejobToEmplyee(ddlProjects.SelectedValue.ToString(), lblId.Text, System.DateTime.Now.ToShortDateString(), Convert.ToInt32(Session["EmpId"]));
                    //if (result > 0)
                    //{
                    //    lblMsg.Text = "Job details alocated to employee";
                    //}
                }
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
        
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        ddlDesg.SelectedIndex = 0;
        //ddlSection.SelectedIndex = 0;
        ddlDept.SelectedIndex = 0;
        lblMsg.Text = "";
        GridView1.Visible = false;
        tblnew.Visible = false;
    }
    
    protected void btnShow_Click(object sender, EventArgs e)
    {
        try
        {
            
            //objUser.Role = ddlDesg.SelectedItem.Text;
            //objDept.HR = Convert.ToInt32(Session["HRId"]);
            DataSet ds = objDept.GetEmployees();
            if (ds.Tables[0].Rows.Count > 0)
            {
                GridView1.DataSource = ds.Tables[0];
                GridView1.DataBind();
                GridView1.Visible = true;
                tblnew.Visible = true;
            }
            else
            {
                lblMsg.Text = "No Records Found..";
                GridView1.Visible = false;
                tblnew.Visible = false;
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    
}
