﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Emp_frmViewMySalary : System.Web.UI.Page
{
    clsUser objUser = new clsUser();
    clsLoanTypes objLoan = new clsLoanTypes();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["EmpId"] != null)
            {
                GetEmpSalaryDetails();
            }
            
        }
    }
    void GetEmpSalaryDetails()
    {
        try
        {
            GvAvailability.Visible = false;
            lblLoan.Visible = false;
            lblMsg.Text = "";
            
                objUser.EmpId = Convert.ToInt32(Session["EmpId"]);
                DataSet ds = objUser.GetSalaryDetailsByEmp();
                if (ds.Tables[0].Rows.Count > 0)
                {
                    GvSal.DataSource = ds.Tables[0];
                    GvSal.DataBind();
                    GvSal.Visible = true;
                }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void GvSal_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (e.CommandName == "Details")
            {
                objLoan.EmpId = Convert.ToInt32(Session["EmpId"]);
                ViewState["Emp"] = Convert.ToInt32(Session["EmpId"]);

                DataSet ds = objLoan.GetLoanDetailsByEmp();
                if (ds.Tables[0].Rows.Count > 0)
                {
                    GvAvailability.DataSource = ds.Tables[0];
                    GvAvailability.DataBind();
                    GvAvailability.Visible = true;
                    lblLoan.Visible = true;
                }
                else
                {
                    lblMsg.Text = "No Loans Found taken by you..";
                    GvAvailability.Visible = false;
                    lblLoan.Visible = false;
                }
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void GvSal_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
