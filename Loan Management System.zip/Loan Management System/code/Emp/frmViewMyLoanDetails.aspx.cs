﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Emp_frmViewMyLoanDetails : System.Web.UI.Page
{
    clsLoanTypes objLoan = new clsLoanTypes();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["EmpId"] != null)
            {
                BindLoanDetails();
            }
        }
    }
    void BindLoanDetails()
    {
        try
        {
            objLoan.EmpId = Convert.ToInt32(Session["EmpId"]);
            DataSet ds = objLoan.GetEmpLoanDetails();
            ViewState["Data"] = ds;
            if (ds.Tables[0].Rows.Count > 0)
            {
                GvLoan.DataSource = ds.Tables[0];
                GvLoan.DataBind();
                GvLoan.Visible = true;                
            }
            else
            {
                lblMsg.Text = "No Loans Found ..";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void GvLoan_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            DataSet ds = (DataSet)ViewState["Data"];
            if (ds.Tables[0].Rows.Count > 0)
            {
                GvLoan.PageIndex = e.NewPageIndex;
                GvLoan.DataSource = ds.Tables[0];
                GvLoan.DataBind();
                GvLoan.Visible = true;
            }
            else
            {
                lblMsg.Text = "No Loans Found ..";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
}
