﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Emp_frmViewLoanAvailability : System.Web.UI.Page
{
    clsDepartment objDept = new clsDepartment();
    clsLoanTypes objLoan = new clsLoanTypes();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["EmpId"] != null)
            {
                BindLoanTypes();
                BindDesg();
            }
        }
    }
    public void BindLoanTypes()
    {
        try
        {
            DataSet ds = objLoan.GetLoanTypes();
            ddlType.DataSource = ds.Tables[0];
            ddlType.DataTextField = "LoanTypeName";
            ddlType.DataValueField = "LoanTypeId";
            ddlType.DataBind();
            ddlType.Items.Insert(0, "--Select LoanType--");
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    public void BindDesg()
    {
        try
        {
            DataSet dsDesg = objDept.GetDesignations();
            ddlDesg.DataSource = dsDesg.Tables[0];
            ddlDesg.DataTextField = "DesgName";
            ddlDesg.DataValueField = "DesignationId";
            ddlDesg.DataBind();
            ddlDesg.Items.Insert(0, "--Select Designation--");
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void ddlType_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            lblMsg.Text = "";
            if (ddlType.SelectedIndex != 0)
            {
                objLoan.DesgId = Convert.ToInt32(ddlDesg.SelectedValue);
                objLoan.LoanTypeId = Convert.ToInt32(ddlType.SelectedValue);

                DataSet ds = objLoan.GetAmountDuration();
                DataRow dr = ds.Tables[0].Rows[0];
                if (ds.Tables[0].Rows.Count > 0)
                {
                    txtAmount.Text = dr["Amount"].ToString();
                    txtDuration.Text = dr["Duration"].ToString();
                }
                else
                {
                    lblMsg.Text = "No Data Available..";
                }
            }
            else
            {
                txtAmount.Text = "";
                txtDuration.Text = "";
                ddlDesg.SelectedIndex = 0;
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
}
