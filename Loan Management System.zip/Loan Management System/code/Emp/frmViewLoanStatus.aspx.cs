﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Emp_frmViewLoanStatus : System.Web.UI.Page
{
    clsLoanTypes objLoan = new clsLoanTypes();

    protected void Page_Load(object sender, EventArgs e)
    {
        lblMsg.Text = "";
        if (!IsPostBack)
        {
            if (Session["EmpId"] != null)
            { 
             
            }
        }
    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        try
        {
            lblMsg.Text = "";
            gvLoan.Visible=false;
            objLoan.EmpId = Convert.ToInt32(Session["EmpId"]);
            objLoan.SNo = Convert.ToInt32(txtLoan.Text);
            DataSet ds = objLoan.GetLoanStatusByLoanId();
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvLoan.DataSource = ds.Tables[0];
                gvLoan.DataBind();
                gvLoan.Visible = true;
            }
            else
            {
                lblMsg.Text = "Please Enter Your Correct Loan Id..";   
                
            }

        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
}
