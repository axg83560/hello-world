function chooseType(id){
	document.getElementById('searchTypeValue').value = id;
	document.getElementById('searchTypeMenu_1').className = '';
	document.getElementById('searchTypeMenu_2').className = '';
	document.getElementById('searchTypeMenu_'+id).className = 'checked';
	document.getElementById('searchTypeIcon').src = 'http://graphics.suite101.com/icon_searchfilter_'+id+'.gif';
	toggleSearchTypes();
}

function toggleSearchTypes(){
	var id = document.getElementById('searchTypeValue').value;
	if(document.getElementById('searchTypes').style.visibility != 'visible'){
		document.getElementById('searchTypeIcon').src = 'http://graphics.suite101.com/icon_searchfilter_'+id+'_active.gif';
		document.getElementById('searchTypes').style.visibility = 'visible';
	}else{
		document.getElementById('searchTypeIcon').src = 'http://graphics.suite101.com/icon_searchfilter_'+id+'.gif';
		document.getElementById('searchTypes').style.visibility = 'hidden';
	}
}