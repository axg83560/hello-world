function toggleNav(nav_img, nav_sec) {
	var e = document.getElementById(nav_sec).style;
	if (nav_img.className=='closed') { 
		nav_img.className='';
		e.height = 'auto';
		e.overflow = '';
	} else {
		nav_img.className='closed';
		e.overflow = 'hidden';
		e.height = '26px';
	}
	padNav();
}
function padNav() {
	var a,b,n,blankSpace;
	if(n = document.getElementById('navBlankBottom')) {
		n.style.height = '1px';
			if(a = document.getElementById('leftNavigation')) {
				if(b = document.getElementById('leftColumn')) {
					blankSpace = a.offsetHeight - b.offsetHeight;
					n.style.height = blankSpace + 'px';
			}
		}
	}
}
function addOnloadEvent(fnc){
	//Calling this function:
	//either: addOnloadEvent(functionName);
	//or:     addOnloadEvent(function(){functionName('argument1','etc')});
	if(typeof window.addEventListener != "undefined") window.addEventListener("load",fnc,false);
	else if(typeof window.attachEvent != "undefined") window.attachEvent("onload",fnc);
	else {
		if(window.onload != null) {
			var oldOnload = window.onload;
			window.onload = function(e) {
				oldOnload(e);
				window[fnc]();
			};
		} else window.onload = fnc;
	}
}