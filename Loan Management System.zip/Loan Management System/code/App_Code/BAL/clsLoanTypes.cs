﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using Global.DAL;
/// <summary>
/// Summary description for clsLoanTypes
/// </summary>
public class clsLoanTypes 
{
	public clsLoanTypes()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public int SNo { get; set; }
    public int LoanTypeId { get; set; }
    public string TypeName { get; set; }
    public string Desc { get; set; }
    public int EmpId { get; set; }
    public int DesgId { get; set; }
    public decimal Amount { get; set; }
    public string Duration { get; set; }
    public int AdvisorId { get; set; }
    public string Request { get; set; }
    public decimal Balance { get; set; }
    public decimal Deduction { get; set; }
    public string DesgName { get; set; }

    public string InsertLoanTypes()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[4];
            p[0] = new SqlParameter("@Name", TypeName);
            //p[1] = new SqlParameter("@Location", Location);
            p[1] = new SqlParameter("@Desc", Desc);
            p[2] = new SqlParameter("@Message", SqlDbType.VarChar, 250);
            p[2].Direction = ParameterDirection.Output;
            p[3] = new SqlParameter("@Advisor", AdvisorId);
            SqlHelper.ExecuteNonQuery(clsConnection.Connection, CommandType.StoredProcedure, "sp_InsertLoanTypes", p);
            return p[2].Value.ToString();
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetLoanTypes()
    {
        try
        {
            string str = "select * from tbl_LoanTypes where Status='Active'";
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.Text, str);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetLoanIds()
    {
        try
        {
            string str = "select SNo from tbl_LoanAvailabilityDetails";
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.Text, str);

        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetLoanStatusByLoanId()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[2];
            p[0] = new SqlParameter("@LoanId", SNo);
            p[1] = new SqlParameter("@EmpId", EmpId);
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure, "sp_GetLoanStatusByLoanId", p);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetAdvisors()
    {
        try
        {
            string str = "select UserId,UserName from tbl_UserRegistration where Role='Advisor' and Status='Active'";
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.Text, str);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetLoanTakenEmployees()
    {
        try
        {
            //string str = "select UserId,UserName from tbl_UserRegistration where Role='Advisor' and Status='Active'";
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure,"sp_GetLoanTakenEmployees",null);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public string InsertLoanAvailability()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[5];
            p[0] = new SqlParameter("@TypeId", LoanTypeId);
            p[1] = new SqlParameter("@DesgId", DesgId);
            p[2] = new SqlParameter("@Amount", Amount);
            p[3] = new SqlParameter("@Duration", Duration);
            p[4] = new SqlParameter("@Message", SqlDbType.VarChar, 250);
            p[4].Direction = ParameterDirection.Output;
            SqlHelper.ExecuteNonQuery(clsConnection.Connection, CommandType.StoredProcedure, "sp_InsertLoanAvailabilityDetails", p);
            return p[4].Value.ToString();
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public string UpdateLoanAvailability()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[4];
            //p[0] = new SqlParameter("@Type", TypeName);
            //p[1] = new SqlParameter("@Desg", DesgName);
            p[0] = new SqlParameter("@Amount", Amount);
            p[1] = new SqlParameter("@Duration", Duration);
            p[2] = new SqlParameter("@Message", SqlDbType.VarChar, 250);
            p[2].Direction = ParameterDirection.Output;
            p[3] = new SqlParameter("@LoanId", SNo);
            SqlHelper.ExecuteNonQuery(clsConnection.Connection, CommandType.StoredProcedure, "sp_UpdateLoanAvailabilityDetails", p);
            return p[2].Value.ToString();
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public string InsertEmpLoanDetails()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[6];
            p[0] = new SqlParameter("@TypeId", LoanTypeId);
            p[1] = new SqlParameter("@Request",Request);
            p[2] = new SqlParameter("@Amount", Amount);
            p[3] = new SqlParameter("@Duration", Duration);
            p[4] = new SqlParameter("@Message", SqlDbType.VarChar, 250);
            p[4].Direction = ParameterDirection.Output;
            p[5] = new SqlParameter("@EmpId", EmpId);
            SqlHelper.ExecuteNonQuery(clsConnection.Connection, CommandType.StoredProcedure, "sp_InsertEmpLoanDetails", p);
            return p[4].Value.ToString();
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetAmountByTypeId()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[2];
            p[0] = new SqlParameter("@TypeId", LoanTypeId);            
            p[1] = new SqlParameter("@EmpId", EmpId);
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure, "sp_GetAmountByTypeId", p);
            
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetAmountDuration()
    {
        try
        {
            string str = "select Amount,Duration from tbl_LoanAvailabilityDetails where DesignationId=" + this.DesgId + " and LoanTypeId=" + this.LoanTypeId;
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.Text, str);

        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetAvailableLoanTypesByEmp()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[1];
            
            p[0] = new SqlParameter("@EmpId", EmpId);
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure, "sp_GetAvailableLoanTypesByEmp", p);

        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetLoanRequests()
    {
        try
        {
            //string str = "select UserId,UserName from tbl_UserRegistration where Role='Advisor' and Status='Active'";
            
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure,"sp_GetLoanRequests",null);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetLoanRequestsByAdvisor()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[1];
            p[0] = new SqlParameter("@AdvisorId", AdvisorId);
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure, "sp_GetLoanRequestsByAdvisor",p);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetEmpLoanDetailsByAdvisor()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[1];
            p[0] = new SqlParameter("@AdvisorId", AdvisorId);
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure, "sp_GetEmpLoanDetailsByAdvisor", p);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public int ChangeRequestStatus()
    {
        try
        {
            string str = "update tbl_EmpLoanDetails set Status='Process' where SNo=" +this.SNo;

            return SqlHelper.ExecuteNonQuery(clsConnection.Connection, CommandType.Text, str);

        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    // This is for Advisor purpose
    public DataSet GetLoanDetailsByEmp()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[1];
            p[0] = new SqlParameter("@EmpId", EmpId);
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure, "sp_GetLoanDetailsByEmp", p);

        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    // This is for Emp purpose
    public DataSet GetEmpLoanDetails()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[1];
            p[0] = new SqlParameter("@EmpId", EmpId);
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure, "sp_GetEmployeeLoanDetails", p);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public string ConfirmLoan()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[2];
            p[0] = new SqlParameter("@SNo", SNo);
            p[1] = new SqlParameter("@Message", SqlDbType.VarChar, 250);
            p[1].Direction = ParameterDirection.Output;
            SqlHelper.ExecuteNonQuery(clsConnection.Connection, CommandType.StoredProcedure, "sp_ConfirmLoan", p);
            return p[1].Value.ToString();
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public string RejectLoan()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[2];
            p[0] = new SqlParameter("@SNo", SNo);
            p[1] = new SqlParameter("@Message", SqlDbType.VarChar, 250);
            p[1].Direction = ParameterDirection.Output;
            SqlHelper.ExecuteNonQuery(clsConnection.Connection, CommandType.StoredProcedure, "sp_RejectLoan", p);
            return p[1].Value.ToString();
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public static string Message { get; set; }
    public static int DeductionAmt { get; set; }
    public static int BalAmt { get; set; }

    public static void GetBalanceByEmp(int EmpId,int LoanTypeId)
    {
        try
        {
            SqlParameter[] p = new SqlParameter[5];

            p[0] = new SqlParameter("@EmpId", EmpId);
            p[1] = new SqlParameter("@LoanTypeId", LoanTypeId);

            p[2] = new SqlParameter("@DedAmt", SqlDbType.Decimal);
            p[2].Direction = ParameterDirection.Output;
            p[3] = new SqlParameter("@BalAmt", SqlDbType.Decimal);
            p[3].Direction = ParameterDirection.Output;
            p[4] = new SqlParameter("@Message", SqlDbType.VarChar, 200);
            p[4].Direction = ParameterDirection.Output;

            SqlHelper.ExecuteNonQuery(clsConnection.Connection, CommandType.StoredProcedure, "sp_GetBalanceByEmp", p);
            DeductionAmt = Convert.ToInt32(p[2].Value);
            BalAmt = Convert.ToInt32(p[3].Value);
            Message = Convert.ToString(p[4].Value);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public string InsertEmpLoanPayments()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[5];

            p[0] = new SqlParameter("@EmpId", EmpId);
            p[1] = new SqlParameter("@LoanTypeId", LoanTypeId);

            p[2] = new SqlParameter("@Deduction", Deduction);
            
            p[3] = new SqlParameter("@Balance", Balance);
          
            p[4] = new SqlParameter("@Message", SqlDbType.VarChar, 250);
            p[4].Direction = ParameterDirection.Output;

            SqlHelper.ExecuteNonQuery(clsConnection.Connection, CommandType.StoredProcedure, "sp_InsertEmpLoanPayments", p);
            return p[4].Value.ToString();
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetLoanAvailabilityDetailsById()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[1];
            p[0] = new SqlParameter("@LoanId", SNo);
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure, "sp_GetLoanAvailabilityDetailsById", p);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
}
