﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using Global.DAL;
/// <summary>
/// Summary description for clsDepartment
/// </summary>
public class clsDepartment 
{
	public clsDepartment()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public int DeptId { get; set; }
    public string DeptName { get; set; }
    public string Location { get; set; }
    public string Desc { get; set; }
    public int BranchId { get; set; }
    public int HR { get; set; }
    public int DesgId { get; set; }
    public string DesgName { get; set; }
    public string Abbreviation { get; set; }

    public int SectionId { get; set; }
    public string SecName { get; set; }
    public int EmpId { get; set; }

    public string AddDept()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[3];
            p[0] = new SqlParameter("@Name", DeptName);
            //p[1] = new SqlParameter("@Location", Location);
            p[1] = new SqlParameter("@Desc", Desc);
            p[2] = new SqlParameter("@Message", SqlDbType.VarChar, 250);
            p[2].Direction = ParameterDirection.Output;
            //p[3] = new SqlParameter("@BranchId", BranchId);
            SqlHelper.ExecuteNonQuery(clsConnection.Connection, CommandType.StoredProcedure, "sp_AddDepartments", p);
            return p[2].Value.ToString();
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }

    }
    public string AddDesignation()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[3];
            p[0] = new SqlParameter("@Name", DesgName);
            p[1] = new SqlParameter("@Abbreviation", Abbreviation);           
            p[2] = new SqlParameter("@Message", SqlDbType.VarChar, 250);
            p[2].Direction = ParameterDirection.Output;

            SqlHelper.ExecuteNonQuery(clsConnection.Connection, CommandType.StoredProcedure, "sp_AddDesignations", p);
            return p[2].Value.ToString();
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public string AddSection()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[3];
            p[0] = new SqlParameter("@Name", SecName);
            p[1] = new SqlParameter("@DeptId", DeptId);
            p[2] = new SqlParameter("@Message", SqlDbType.VarChar, 250);
            p[2].Direction = ParameterDirection.Output;

            SqlHelper.ExecuteNonQuery(clsConnection.Connection, CommandType.StoredProcedure, "sp_AddSections", p);
            return p[2].Value.ToString();
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetDepartments()
    {
        try
        {
            string str = "select * from tbl_Departments where Status='Active'";
         return  SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.Text,str);

        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetDepartmentsByHR()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[1];
            p[0] = new SqlParameter("@HR", HR);
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure,"sp_GetDepartmentsByHR",p);

        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetDeptDesgByEmp()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[1];
            p[0] = new SqlParameter("@EmpId",EmpId);
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure, "sp_GetDeptDesgByEmp", p);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetDesignations()
    {
        try
        {
            string str = "select * from tbl_Designations where Status='Active'";
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.Text, str);

        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetSectionsByDept()
    {
        try
        {
            string str = "select * from tbl_Sections where Status='Active' and DepartmentId="+this.DeptId;
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.Text, str);

        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetSections()
    {
        try
        {
            string str = "select * from tbl_Sections where Status='Active' ";
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.Text, str);

        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetEmployees()
    {
        try
        {
            string str = "select * from tbl_UserRegistration where Role='Emp' and Status='Active'";
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.Text, str);

        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetEmployeesByHR()
    {
        try
        {
            string str = "select * from tbl_UserRegistration where Role='Emp' and Status='Active' and RecruitedBy="+this.HR;
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.Text, str);

        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetWorkingEmployees()
    {
        try
        {
            string str = "select * from tbl_UserRegistration where Role='Emp' and Status='Assigned'";
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.Text, str);

        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetEmployeesForSalary()
    {
        try
        {
            //string str = "select * from tbl_UserRegistration where Role='Emp' and Status='Assigned'";
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure,"sp_GetEmployees",null);

        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetEmpDetailsById()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[1];
            p[0] = new SqlParameter("@EmpId", EmpId);
            //string str = "select * from tbl_Emp_Dept where Status='Active' and EmpId="+this.EmpId;
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure,"sp_GetEmpDetailsById",p);

        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public string AssignEmpToDept()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[4];
            p[0] = new SqlParameter("@EmpId", EmpId);
            p[1] = new SqlParameter("@DeptId", DeptId);
            //p[2] = new SqlParameter("@HR", HR);
            p[2] = new SqlParameter("@Message", SqlDbType.VarChar, 250);
            p[2].Direction = ParameterDirection.Output;
            p[3] = new SqlParameter("@DesgId", DesgId);

            SqlHelper.ExecuteNonQuery(clsConnection.Connection, CommandType.StoredProcedure, "sp_AssignEmpToDept", p);
            return p[2].Value.ToString();
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public string UpdateEmpJobDetails()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[5];
            p[0] = new SqlParameter("@EmpId", EmpId);
            p[1] = new SqlParameter("@DeptId", DeptId);
            p[2] = new SqlParameter("@SectionId", SectionId);
            p[3] = new SqlParameter("@Message", SqlDbType.VarChar, 250);
            p[3].Direction = ParameterDirection.Output;
            p[4] = new SqlParameter("@DesgId", DesgId);

            SqlHelper.ExecuteNonQuery(clsConnection.Connection, CommandType.StoredProcedure, "sp_UpdateEmpJobDetails", p);
            return p[3].Value.ToString();
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
}
