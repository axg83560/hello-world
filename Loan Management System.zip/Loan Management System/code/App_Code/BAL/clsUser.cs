﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using Global.DAL;
/// <summary>
/// Summary description for clsUser
/// </summary>
public class clsUser 
{
	public clsUser()
	{
		//
		// TODO: Add constructor logic here
		//
	}
   
    public string FirstName { get; set; }
    public string MiddleName { get; set; }
    public string LastName { get; set; }
    public string Email { get; set; }
    public string Address { get; set; }
    public string PhoneNo { get; set; }
    public int UserId { get; set; }
    public string UserName { get; set; }
    public string Password { get; set; }
    public DateTime DOB { get; set; }
    public byte[] Image { get; set; }
    public string FileName { get; set; }
    public DateTime DOR { get; set; }
    public string Role { get; set; }
    
    public string Qualification { get; set; }
    
    public string Gender { get; set; }
    public string Question { get; set; }
    public string Answer { get; set; }
    public int RecruitedBy { get; set; }
    public int BranchId { get; set; }
    public int EmpId { get; set; }
    public int DeptId { get; set; }
    public string DeptName { get; set; }
    public int DesgId { get; set; }
    public string DesgName { get; set; }
    public decimal Basic { get; set; }
    public decimal HRA { get; set; }
    public Decimal DA { get; set; }
    public decimal TA { get; set; }

    public string InsertUserRegistration()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[17];
            p[0] = new SqlParameter("@UserName", UserName);
            p[1] = new SqlParameter("@Password", Password);
            p[2] = new SqlParameter("@FirstName", FirstName);
            p[3] = new SqlParameter("@MiddleName", MiddleName);
            p[4] = new SqlParameter("@LastName", LastName);
            p[5] = new SqlParameter("@Email", Email);
            p[6] = new SqlParameter("@Address", Address);
            p[7] = new SqlParameter("@Phone", PhoneNo);
            p[8] = new SqlParameter("@DOB", DOB);
            p[9] = new SqlParameter("@DOR", DOR);
            p[10] = new SqlParameter("@Image", Image);
            p[11] = new SqlParameter("@FileName", FileName);
            p[12] = new SqlParameter("@Message", SqlDbType.VarChar, 250);
            p[12].Direction = ParameterDirection.Output;
            p[13] = new SqlParameter("@Hint", Question);
            p[14] = new SqlParameter("@Answer", Answer);
            p[15] = new SqlParameter("@Role", Role);
            p[16] = new SqlParameter("@Qual", Qualification);
            //p[17] = new SqlParameter("@RecruitedBy", RecruitedBy);
            SqlHelper.ExecuteNonQuery(clsConnection.Connection, CommandType.StoredProcedure, "sp_InsertUserRegistration", p);
            return p[12].Value.ToString();
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public string ForgotPassword()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[4];
            p[0] = new SqlParameter("@UserName", UserName);
            p[1] = new SqlParameter("@Hint", Question);
            p[2] = new SqlParameter("@Answer", Answer);
            p[3] = new SqlParameter("@Message", SqlDbType.VarChar, 250);
            p[3].Direction = ParameterDirection.Output;
            SqlHelper.ExecuteNonQuery(clsConnection.Connection, CommandType.StoredProcedure, "sp_ForgotPassword", p);
            return p[3].Value.ToString();
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetBranches()
    {
        try
        {
           return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure,"sp_GetBranches",null);

        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public string AssignEmpToBranch()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[3];
            p[0] = new SqlParameter("@EmpId", UserId);
            p[1] = new SqlParameter("@BranchId", BranchId);
            p[2] = new SqlParameter("@Message", SqlDbType.VarChar, 250);
            p[2].Direction = ParameterDirection.Output;
            SqlHelper.ExecuteNonQuery(clsConnection.Connection, CommandType.StoredProcedure, "sp_AssignEmployeesToBranch", p);
            return p[2].Value.ToString();
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetEmployees()
    {
        try
        {
            string str = "select * from tbl_UserRegistration where Role='Emp'and Status='Assigned'";
           return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.Text,str);

        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetEmployeesReport()
    {
        try
        {
            //string str = "select * from tbl_UserRegistration where Role='Customer'";
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure,"sp_GetEmployeesReport",null);

        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetAdvisorsReport()
    {
        try
        {
            //string str = "select * from tbl_UserRegistration where Role='Customer'";
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure, "sp_GetAdvisorsReport", null);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetAllDesg()
    {
        try
        {
            string str = "select distinct Role from tbl_UserRegistration where Role !='Admin' and Role !='User'";
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.Text, str);

        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetEmpByDesg()
    {
        try
        {
            string str = "select * from tbl_UserRegistration where Role='" + this.Role + "' and Status='Active'";
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.Text, str);

        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    
    public string AcceptRegdUsers()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[2];
            p[0] = new SqlParameter("@UserId", UserId);
            p[1] = new SqlParameter("@Message", SqlDbType.VarChar, 100);
            p[1].Direction = ParameterDirection.Output;
            //p[2] = new SqlParameter("@AdminId", SenderId);
            SqlHelper.ExecuteNonQuery(clsConnection.Connection, CommandType.StoredProcedure, "sp_AcceptRegdUsers", p);
            return p[1].Value.ToString();
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public string RejectRegdUsers()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[2];
            p[0] = new SqlParameter("@UserId", UserId);
            p[1] = new SqlParameter("@Message", SqlDbType.VarChar, 100);
            p[1].Direction = ParameterDirection.Output;
            // p[2] = new SqlParameter("@AdminId", SenderId);
            SqlHelper.ExecuteNonQuery(clsConnection.Connection, CommandType.StoredProcedure, "sp_RejectRegdUsers", p);
            return p[1].Value.ToString();
        }
        catch (Exception ex)
        {

            throw new ArgumentException(ex.Message);
        }
    }
    public string InsertSalaryDetails()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[7];
            p[0] = new SqlParameter("@EmpId", EmpId);
            p[1] = new SqlParameter("@Dept", DeptName);
            p[2]=new SqlParameter("@Desg",DesgName);
            p[3]=new SqlParameter ("@Basic",Basic);
            p[4] = new SqlParameter("@HRA", HRA);
            p[5] = new SqlParameter("@DA", DA);

            p[6] = new SqlParameter("@Message", SqlDbType.VarChar, 250);
            p[6].Direction = ParameterDirection.Output;

            SqlHelper.ExecuteNonQuery(clsConnection.Connection, CommandType.StoredProcedure, "sp_InsertSalaryDetails", p);
            return p[6].Value.ToString();
        }
        catch (Exception ex)
        {

            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetSalaryDetailsByEmp()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[1];
            p[0] = new SqlParameter("@EmpId", EmpId);
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure, "sp_GetSalaryDetailsByEmp", p);

        }
        catch (Exception ex)
        {

            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet BindEmployees()
    {
        try
        {
          return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure, "sp_BindEmployees", null);

        }
        catch (Exception ex)
        {

            throw new ArgumentException(ex.Message);
        }
    }
}
