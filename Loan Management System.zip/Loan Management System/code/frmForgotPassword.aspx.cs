﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Web.Mail;
public partial class frmForgotPassword : System.Web.UI.Page
{
    clsUser objUser = new clsUser();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        { 
        

        }
    }
    
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            objUser.UserName = txtUser.Text;
            objUser.Question = ddlHint.SelectedItem.Text;
            objUser.Answer = txtAnswer.Text;
            lblMsg.Text = objUser.ForgotPassword();

        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        txtAnswer.Text = "";
        txtUser.Text = "";
        ddlHint.SelectedIndex = 0;
        lblMsg.Text = "";
    }
}
