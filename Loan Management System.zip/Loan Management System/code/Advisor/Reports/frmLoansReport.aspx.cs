﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Advisor_Reports_frmLoansReport : System.Web.UI.Page
{
    clsLoanTypes objLoan = new clsLoanTypes();
    protected void Page_Load(object sender, EventArgs e)
    {
        lblMsg.Text = "";
        if (!IsPostBack)
        {
            if (Session["AdvisorId"] != null)
            {
                GetEmpLoanDetails();
                btnPrint.Visible = false;
            }
        }
    }
    void GetEmpLoanDetails()
    {
        try
        {
            lblMsg.Text="";
            GvEmp.Visible=false;

            objLoan.AdvisorId = Convert.ToInt32(Session["AdvisorId"]);
            DataSet ds = objLoan.GetEmpLoanDetailsByAdvisor();
            ViewState["Data"] = ds;
            if (ds.Tables[0].Rows.Count > 0)
            {
                GvEmp.DataSource = ds.Tables[0];
                GvEmp.DataBind();
                GvEmp.Visible = true;
                btnPrint.Visible=true;
            }
            else
            {
                lblMsg.Text = "No Loans Available..";
                btnPrint.Visible = false;
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
        
    }
    protected void GvEmp_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            DataSet ds = (DataSet)ViewState["Data"];
            if (ds.Tables[0].Rows.Count > 0)
            {
                GvEmp.PageIndex = e.NewPageIndex;
                GvEmp.DataSource = ds.Tables[0];
                GvEmp.DataBind();
                GvEmp.Visible = true;
                btnPrint.Visible = true;
            }
            else
            {
                lblMsg.Text = "No Records Available..";
                btnPrint.Visible = false;
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
}
