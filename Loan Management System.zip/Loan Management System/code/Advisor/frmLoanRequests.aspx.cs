﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Advisor_frmLoanRequests : System.Web.UI.Page
{
    clsLoanTypes objLoan = new clsLoanTypes();
    protected void Page_Load(object sender, EventArgs e)
    {
        lblLoan.Visible = false;
        if (!IsPostBack)
        {
            if (Session["AdvisorId"] != null)
            {
                GetLoanRequests();
            }
        }
    }
    void GetLoanRequests()
    {
        try
        {
            objLoan.AdvisorId = Convert.ToInt32(Session["AdvisorId"]);
            DataSet ds = objLoan.GetLoanRequestsByAdvisor();
            ViewState["Data"] = ds;
            if (ds.Tables[0].Rows.Count > 0)
            {
                GvLoan.DataSource = ds.Tables[0];
                GvLoan.DataBind();
                GvLoan.Visible = true;
            }
            else
            {
                lblMsg.Text = "No Requests Available..";
                GvLoan.Visible = false;
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }

    protected void GvLoan_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            DataSet ds = (DataSet)ViewState["Data"];
            if (ds.Tables[0].Rows.Count > 0)
            {
                GvLoan.PageIndex = e.NewPageIndex;
                GvLoan.DataSource = ds.Tables[0];
                GvLoan.DataBind();
                GvLoan.Visible = true;
            }
            else
            {
                lblMsg.Text = "No Requests Available..";
                GvLoan.Visible = false;
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void GvLoan_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            lblMsg.Text = "";
            //tblTime.Visible = false;
            GvAvailability.Visible = false;

            if (e.CommandName == "Availability")
            {
                //GridViewRow drow = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
                //lbldate = (Label)drow.FindControl("lbldate");
                //objApmt.Date = Convert.ToDateTime(lbldate.Text);
                //ViewState["Date"] = lbldate.Text;

                objLoan.EmpId = Convert.ToInt32(e.CommandArgument);
                ViewState["Emp"] = Convert.ToInt32(e.CommandArgument);
                
                DataSet ds = objLoan.GetLoanDetailsByEmp();
                if (ds.Tables[0].Rows.Count > 0)
                {
                    GvAvailability.DataSource = ds.Tables[0];
                    GvAvailability.DataBind();
                    GvAvailability.Visible = true;
                    lblLoan.Visible = true;
                }
                else
                {
                    lblMsg.Text = "No Loans Found taken by this Employee..";
                    GvAvailability.Visible = false;
                    lblLoan.Visible = false;
                }
            }
            else if (e.CommandName == "Confirm")
            {
                objLoan.SNo = Convert.ToInt32(e.CommandArgument);
                //ViewState["SNo"] = SNo;                
                lblMsg.Text = objLoan.ConfirmLoan();
                GetLoanRequests();
                //tblTime.Visible = true;
            }
            else if (e.CommandName == "Reject")
            {
                //tblTime.Visible = false;
                GvAvailability.Visible = false;
                objLoan.SNo = Convert.ToInt32(e.CommandArgument);
                lblMsg.Text = objLoan.RejectLoan();
                GetLoanRequests();
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
        
    }
}
